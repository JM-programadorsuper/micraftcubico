// Backend do Mundo Cúbico: contas, nuvem e salas multijogador — só Netlify Functions + Netlify Blobs.
import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";

export const config = { path: "/api" };

const mk = (n) => getStore({ name: n, consistency: "strong" });
const hex = (n) => crypto.randomBytes(n).toString("hex");
const scrypt = (p, salt) => new Promise((ok, no) => crypto.scrypt(p, salt, 32, (e, k) => (e ? no(e) : ok(k.toString("hex")))));
const NOME = /^[a-z0-9_]{3,14}$/, CHAVE = /^[A-Za-z0-9_.\-]{1,64}$/, SALA = /^[A-Za-z0-9\-_]{1,24}$/;

export async function handle(b, S) {
  const op = b && b.op;
  const sess = async () => {
    if (!b.token || typeof b.token !== "string" || b.token.length > 80) return null;
    const s = await S.sess.get("t/" + b.token, { type: "json" });
    return s && Date.now() - s.t < 60 * 864e5 ? s : null;
  };
  if (op === "register" || op === "login") {
    const u = String(b.u || "").trim().toLowerCase(), p = String(b.p || "");
    if (!NOME.test(u)) return { ok: false, err: "nome" };
    if (p.length < 4 || p.length > 64) return { ok: false, err: "senha" };
    let uid;
    if (op === "register") {
      const salt = hex(16), h = await scrypt(p, salt);
      uid = hex(8);
      const r = await S.users.set("u/" + u, JSON.stringify({ uid, salt, h }), { onlyIfNew: true });
      if (!r.modified) return { ok: false, err: "taken" };
    } else {
      const rec = await S.users.get("u/" + u, { type: "json" });
      if (!rec) return { ok: false, err: "login" };
      const h = await scrypt(p, rec.salt);
      if (!crypto.timingSafeEqual(Buffer.from(h), Buffer.from(rec.h))) return { ok: false, err: "login" };
      uid = rec.uid;
    }
    const token = hex(24);
    await S.sess.set("t/" + token, JSON.stringify({ uid, u, t: Date.now() }));
    return { ok: true, token, uid, u };
  }
  if (op === "me") { const s = await sess(); return s ? { ok: true, uid: s.uid, u: s.u } : { ok: false }; }
  if (op === "logout") { if (b.token && typeof b.token === "string") await S.sess.delete("t/" + b.token); return { ok: true }; }
  if (op === "get" || op === "set" || op === "del") {
    const s = await sess(); if (!s) return { ok: false, err: "auth" };
    if (!CHAVE.test(String(b.key || ""))) return { ok: false, err: "key" };
    const k = s.uid + "/" + b.key;
    if (op === "get") { const v = await S.data.get(k); return { ok: true, v: v == null ? null : v }; }
    if (op === "del") { await S.data.delete(k); return { ok: true }; }
    if (typeof b.v !== "string" || b.v.length > 1.2e6) return { ok: false, err: "size" };
    await S.data.set(k, b.v); return { ok: true };
  }
  if (op === "rt") {
    const room = String(b.room || "");
    if (!SALA.test(room) || typeof b.peer !== "string" || b.peer.length > 16) return { ok: false, err: "room" };
    const key = "r/" + room, now = Date.now(), peer = b.peer;
    const evIn = Array.isArray(b.ev) ? b.ev.slice(0, 40).filter((e) => e && typeof e.t === "string" && e.t.length < 8 && JSON.stringify(e.d || {}).length < 6000) : [];
    for (let tries = 0; tries < 6; tries++) {
      const cur = await S.rooms.getWithMetadata(key, { type: "json" });
      const d = cur && cur.data ? cur.data : { seq: 0, ev: [], pe: {} };
      let dirty = false;
      for (const k of Object.keys(d.pe)) if (now - d.pe[k].ts > 12000) { delete d.pe[k]; dirty = true; }
      const n0 = d.ev.length; d.ev = d.ev.filter((e) => now - e.ts < 40000); if (d.ev.length !== n0) dirty = true;
      if (b.leave) { if (d.pe[peer]) { delete d.pe[peer]; dirty = true; } }
      else {
        if (evIn.length) { for (const e of evIn) d.ev.push({ s: ++d.seq, p: peer, t: e.t, d: e.d || {}, ts: now }); dirty = true; }
        const me = d.pe[peer];
        if (b.pres && typeof b.pres === "object" && JSON.stringify(b.pres).length < 1500) { d.pe[peer] = { pr: b.pres, ts: now }; dirty = true; }
        else if (!me) { d.pe[peer] = { pr: {}, ts: now }; dirty = true; }
        else if (now - me.ts > 4000) { me.ts = now; dirty = true; }
      }
      while (JSON.stringify(d.ev).length > 350000 && d.ev.length) d.ev.shift();
      if (dirty) {
        const r = await S.rooms.set(key, JSON.stringify(d), cur && cur.etag ? { onlyIfMatch: cur.etag } : { onlyIfNew: true });
        if (!r.modified) continue;
      }
      const since = typeof b.since === "number" ? b.since : -1;
      const ev = since < 0 ? [] : d.ev.filter((e) => e.s > since && e.p !== peer).map((e) => ({ s: e.s, p: e.p, t: e.t, d: e.d }));
      return { ok: true, seq: d.seq, ev, pe: Object.entries(d.pe).map(([p, v]) => ({ peer: p, pr: v.pr })) };
    }
    return { ok: false, err: "busy" };
  }
  return { ok: false, err: "op" };
}

export default async (req) => {
  const H = { "content-type": "application/json", "cache-control": "no-store" };
  if (req.method !== "POST") return new Response('{"ok":false}', { status: 405, headers: H });
  try {
    const raw = await req.text();
    if (raw.length > 1.5e6) return new Response('{"ok":false,"err":"size"}', { status: 413, headers: H });
    const out = await handle(JSON.parse(raw), { users: mk("users"), sess: mk("sess"), data: mk("data"), rooms: mk("rooms") });
    return new Response(JSON.stringify(out), { headers: H });
  } catch (e) {
    return new Response('{"ok":false,"err":"srv"}', { status: 500, headers: H });
  }
};
